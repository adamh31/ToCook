/**
 * Copyright (C) 2014 - 2021 DLSC Software & Consulting GmbH (dlsc.com)
 *
 * This file is part of FlexGanttFX.
 */
module com.flexganttfx.tutorials {
    requires javafx.graphics;
    requires com.flexganttfx.view;
    exports com.flexganttfx.tutorial;
}