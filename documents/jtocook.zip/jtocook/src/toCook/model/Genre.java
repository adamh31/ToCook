package toCook.model;

public class Genre {
    
}
