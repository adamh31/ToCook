
package toCook.DAO;
import java.util.HashMap;
import toCook.model.Commune;

public interface VilleDAOInterface {
    public static HashMap<Integer, Commune> villesPourCp(String codePostal) {
        HashMap<Integer, Commune> listVilles = new HashMap<>();
        // code à implémenter
        return listVilles;
    }

    
}
