/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package toCook.model;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Before;
import org.junit.After;

import java.util.Date;
import java.text.SimpleDateFormat;

public class DiffusionTest {

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void testToXML() throws Exception {
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-mm-dd");
        Date uneDate = sf.parse("2019-06-01");

        CategorieCSA uneCateg = new CategorieCSA("TP", "Tout public");
        Emission uneEmi = new Emission(212234, "Chefs Saison 1");
        Programme unProg = new Programme(uneEmi, 1, "Épisode 1", 47, uneCateg);
        Diffusion uneDiff = new Diffusion(unProg, 8, uneDate, "13:30:00", false);
        String resultat = "<diffusion>"
                + "<horaire > 13:30:00</horaire>"
                + "<duree>47</duree>"
                + "<emission> Chefs Saison 1 </emission>"
                + "<programme>Épisode 1</programme>"
                + "<csa>Tout public</csa>"
                + "</diffusion>";
    }

    //Méthode " tearDown()" automatiquement exécutée après chaque appel de méthode de test
    @After
    public void tearDown() throws Exception {
    }
}
